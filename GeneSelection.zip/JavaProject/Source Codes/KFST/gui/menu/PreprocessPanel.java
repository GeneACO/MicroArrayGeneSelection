/*
 * Kurdistan Feature Selection Tool (KFST) is an open-source tool, developed
 * completely in Java, for performing feature selection process in different
 * areas of research.
 * For more information about KFST, please visit:
 *     http://kfst.uok.ac.ir/index.html
 *
 * Copyright (C) 2016 KFST development team at University of Kurdistan,
 * Sanandaj, Iran.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package KFST.gui.menu;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
//import javax.swing.UIManager;

/**
 * This java class is used to create and show a panel for preprocessing of the
 * datasets.
 *
 * @author Shahin Salavati
 * @author Sina Tabakhi
 */
public class PreprocessPanel extends JFrame
        implements ActionListener {

    JLabel lbl_about, lbl_inputFile;
    JTextField txt_inputFile;
    JButton btn_selectFile, btn_save, btn_close;
    JPanel panel_about, panel_delimiter;
    JRadioButton rd_tab, rd_semicolon, rd_space, rd_comma;
    ButtonGroup btnGroup;
    JCheckBox ch_convert, ch_transpose;

    /**
     * Creates new form PreprocessPanel. This method is called from within the
     * constructor to initialize the form.
     */
    public PreprocessPanel() {

        panel_about = new JPanel();
        panel_about.setBounds(10, 30, 465, 60);
        panel_about.setLayout(null);
        panel_about.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "About"));
        lbl_about = new JLabel("This screen lets you prepare the dataset in the KFST format.");
        lbl_about.setBounds(15, 2, 455, 60);

        panel_about.add(lbl_about);

        /////////////////////// input file section ////////////////////////////
        lbl_inputFile = new JLabel("Select input file:");
        lbl_inputFile.setBounds(30, 110, 110, 22);
        txt_inputFile = new JTextField();
        txt_inputFile.setBounds(120, 110, 200, 21);
        txt_inputFile.setEditable(false);
        txt_inputFile.setBackground(Color.WHITE);
        btn_selectFile = new JButton("Open file...");
        btn_selectFile.setBounds(340, 108, 100, 23);
        btn_selectFile.addActionListener(this);


        /////////////////////// Delimiter panel ///////////////////////////////
        panel_delimiter = new JPanel();
        panel_delimiter.setBounds(30, 160, 105, 130);
        panel_delimiter.setLayout(null);
        panel_delimiter.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Delimiter"));


        rd_tab = new JRadioButton("Tab");
        rd_tab.setBounds(10, 25, 85, 22);
        rd_semicolon = new JRadioButton("Semicolon");
        rd_semicolon.setBounds(10, 50, 85, 22);
        rd_space = new JRadioButton("Space");
        rd_space.setBounds(10, 75, 85, 22);
        rd_comma = new JRadioButton("Comma");
        rd_comma.setBounds(10, 100, 85, 22);
        rd_tab.setSelected(true);
        btnGroup = new ButtonGroup();
        btnGroup.add(rd_tab);
        btnGroup.add(rd_semicolon);
        btnGroup.add(rd_space);
        btnGroup.add(rd_comma);

        panel_delimiter.add(rd_tab);
        panel_delimiter.add(rd_semicolon);
        panel_delimiter.add(rd_space);
        panel_delimiter.add(rd_comma);

        /////////////////////// check box section /////////////////////////////
        ch_convert = new JCheckBox("Convert to Comma delimited");
        ch_convert.setBounds(150, 200, 230, 22);

        ch_transpose = new JCheckBox("Transpose (rotate) dataset from rows to columns or vice versa");
        ch_transpose.setBounds(150, 230, 380, 22);

        btn_save = new JButton("Save file...");
        btn_save.setBounds(140, 310, 90, 23);
        btn_save.setEnabled(false);
        btn_save.addActionListener(this);

        btn_close = new JButton("Close");
        btn_close.setBounds(250, 310, 90, 23);
        btn_close.addActionListener(this);


        add(panel_about);

        add(lbl_inputFile);
        add(txt_inputFile);
        add(btn_selectFile);

        add(panel_delimiter);

        add(ch_convert);
        add(ch_transpose);
        add(btn_save);
        add(btn_close);


        setLayout(null);
        setSize(490, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setIconImage(new ImageIcon(getClass().getResource("/KFST/gui/icons/small_logo.png")).getImage());
        setTitle("Preprocessing Panel");
        setResizable(false);
        setVisible(true);
    }

    /**
     * The listener method for receiving action events.
     * Invoked when an action occurs.
     *
     * @param e an action event
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(btn_selectFile)) {
            btn_selectFileActionPerformed(e);
        } else if (e.getSource().equals(btn_save)) {
            btn_saveActionPerformed(e);
        } else if (e.getSource().equals(btn_close)) {
            btn_closeActionPerformed(e);
        }
    }

    /**
     * This method sets an action for the btn_selectFile button.
     *
     * @param e an action event
     */
    private void btn_selectFileActionPerformed(ActionEvent e) {
        JFileChooser jfch = new JFileChooser();
        jfch.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        if (jfch.showOpenDialog(btn_selectFile) == JFileChooser.APPROVE_OPTION) {
            txt_inputFile.setText(jfch.getSelectedFile().getPath());
            btn_save.setEnabled(true);
        }
    }

    /**
     * This method sets an action for the btn_save button.
     *
     * @param e an action event
     */
    private void btn_saveActionPerformed(ActionEvent e) {
        char delimiter;
        String oldPath = txt_inputFile.getText();
        String newPath = "";

        JFileChooser jfch = new JFileChooser();
        jfch.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (jfch.showSaveDialog(btn_save) == JFileChooser.APPROVE_OPTION) {
            newPath = jfch.getSelectedFile().getAbsolutePath() + "\\NewData.data";
        }

        if (rd_tab.isSelected()) {
            delimiter = '	';
        } else if (rd_semicolon.isSelected()) {
            delimiter = ';';
        } else if (rd_space.isSelected()) {
            delimiter = ' ';
        } else {
            delimiter = ',';
        }

        if (ch_convert.isSelected() && !ch_transpose.isSelected()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(oldPath));
                PrintWriter pw = new PrintWriter(new FileWriter(newPath, false));
                while (br.ready()) {
                    pw.println(br.readLine().replace(delimiter, ','));
                }
                br.close();
                pw.close();
            } catch (IOException ex) {
                Logger.getLogger(PreprocessPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (ch_transpose.isSelected()) {
            int numRow = 1;
            int numCol = 0;
            //counts the number of lines in the input file
            try {
                BufferedReader br = new BufferedReader(new FileReader(oldPath));
                numCol = br.readLine().split(Character.toString(delimiter)).length;
                while (br.ready()) {
                    br.readLine();
                    numRow++;
                }
                br.close();
            } catch (IOException ex) {
                Logger.getLogger(PreprocessPanel.class.getName()).log(Level.SEVERE, null, ex);
            }

            //transpose (rotate) dataset from rows to columns or vice versa
            try {
                BufferedReader br = new BufferedReader(new FileReader(oldPath));
                PrintWriter pw = new PrintWriter(new FileWriter(newPath, false));
                String[][] tempArray = new String[numRow][numCol];
                int counter = 0;

                while (br.ready()) {
                    tempArray[counter++] = br.readLine().split(Character.toString(delimiter));
                }
                br.close();

                //if the original data are separated by comma delimiter
                if (ch_convert.isSelected()) {
                    delimiter = ',';
                }
                for (int i = 0; i < numCol; i++) {
                    for (int j = 0; j < numRow - 1; j++) {
                        pw.print(tempArray[j][i] + delimiter);
                    }
                    pw.println(tempArray[numRow - 1][i]);
                }
                pw.close();
            } catch (IOException ex) {
                Logger.getLogger(PreprocessPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * This method sets an action for the btn_close button.
     *
     * @param e an action event
     */
    private void btn_closeActionPerformed(ActionEvent e) {
        dispose();
    }

//    public static void main(String[] arg) {
//        try {
//            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
//        } catch (Exception e) {
//            System.out.println("Error setting native LAF: " + e);
//        }
//
//        PreprocessPanel processPanel = new PreprocessPanel();
//    }
}
